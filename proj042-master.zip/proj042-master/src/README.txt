main.c contains sample code.
ece198.c contains library functions.
ece198.h is a header file giving prototypes definitions for the functions.

In the main.c file, you'll find a lot of sample code. We use conditional compilation
to select which sample is being used. Simply uncomment one (and only one) of the #define
statements at the top to compile the corresponding demo.

Feel free to use and modify any of the code you find here.
